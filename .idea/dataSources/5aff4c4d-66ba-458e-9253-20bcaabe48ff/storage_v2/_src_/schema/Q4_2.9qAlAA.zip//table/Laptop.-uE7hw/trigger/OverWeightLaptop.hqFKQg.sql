create trigger OverWeightLaptop
  before INSERT
  on Laptop
  for each row
BEGIN
    IF NEW.weight > 5000 THEN
        SET NEW.weight = NULL;
    END IF;
    END;

